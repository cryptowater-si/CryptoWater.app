# DomanControler

Treafiker container, for reverse proxy. Handles ssl (auto-renew) and any exposed container


### Setup:
 - Change ``treafik.toml`` domain
 - From root folder run ``bin/install.sh``
 - Change ``.env`` file

### Start // Stop
    - /bin/start_domain_controler.sh
    - /bin/stop_domain_controler.sh